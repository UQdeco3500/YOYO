# poppy

1. npm install
2. npm run serve
3. open the url: localhost:8080
4. you can see the page
